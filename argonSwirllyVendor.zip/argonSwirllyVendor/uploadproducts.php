
<?php
session_start();
include 'dbconnect.php';

$target_dir = "products/";
$target_file1 = $target_dir . basename($_FILES["product1"]["name"]);
$target_file2 = $target_dir . basename($_FILES["product2"]["name"]);
$target_file3 = $target_dir . basename($_FILES["product3"]["name"]);
$target_file4 = $target_dir . basename($_FILES["product4"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file1,PATHINFO_EXTENSION));

// Check if image file is a actual image or fake image
if(isset($_POST["add"])) {
    //getting address
    
    $product_name = $_POST['product_name'];
    $product_price = $_POST['product_price'];
    $description = $_POST['description'];   
   $check = getimagesize($_FILES["product1"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
}
// Check if file already exists
/*if (file_exists($target_file1)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}*/
// Check file size
/*if ($_FILES["product1"]["size"] > 50000000000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}*/
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["product1"]["tmp_name"], $target_file1) OR move_uploaded_file($_FILES["product2"]["tmp_name"], $target_file2) OR move_uploaded_file($_FILES["product3"]["tmp_name"], $target_file3) OR move_uploaded_file($_FILES["product4"]["tmp_name"], $target_file4)) {
        echo $path1 = $target_dir . basename( $_FILES["product1"]["name"]);
        echo $path2 = $target_dir . basename( $_FILES["product2"]["name"]);
        echo $path3 = $target_dir . basename( $_FILES["product3"]["name"]);
        echo $path4 = $target_dir . basename( $_FILES["product4"]["name"]);

        /*echo "The file ". basename( $_FILES["product1"]["name"]). " has been uploaded.";*/

        

        $sql = "INSERT INTO `product_tbl`( `vid`, `p_name`, `p_price`,`p_description`, `p_image1`, `p_image2`, `p_image3`, `p_image4`) VALUES ('$_SESSION[vid]','$product_name','$product_price','$description','$path1','$path2','$path3','$path4')";
        if(mysqli_query($con,$sql)){
            echo" <script>
            alert('SUCCESSFULLY UPLOADED');
            window.location.href = 'addproducts.php';
            </script>";
        }
        
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}
?>
