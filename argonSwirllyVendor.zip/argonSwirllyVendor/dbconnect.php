<?php

/*$con = mysqli_connect("192.168.137.1","swirlly_user","1","swirllyDB");*/
$con = mysqli_connect("localhost","root","","swirllyDB");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
 else{
 	 "Connected to MySQL";
 }
?>
