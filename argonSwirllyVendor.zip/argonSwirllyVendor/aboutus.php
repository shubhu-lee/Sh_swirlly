<?php
    include 'navbar.php';
    ?>
<!--

=========================================================
* Argon Design System - v1.1.0
=========================================================

* Product Page: https://www.creative-tim.com/product/argon-design-system
* Copyright 2019 Creative Tim (https://www.creative-tim.com)
* Licensed under MIT (https://github.com/creativetimofficial/argon-dashboard/blob/master/LICENSE.md)

* Coded by Creative Tim

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software. -->

<!DOCTYPE html>
<html lang="en">
<head>
  
  <title>About Us</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  

</head>
<style type="text/css">
    .already{
    background: transparent;
    border: none;
    color: #2980b9;}
   a:link {
  text-decoration: none;
}

::-webkit-scrollbar-thumb{
  background: blue;
}

  .responsive {
    width: 100px;
    height: auto;
}
  </style>

<body>



<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Start your development with a Design System for Bootstrap 4.">
  <meta name="author" content="Creative Tim">
  <!-- Favicon -->
  <link href="./assets/img/brand/Swirlly.png" rel="icon" type="image/png">
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  <link href="assets/vendor/nucleo/css/nucleo.css" rel="stylesheet">
  <link href="assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <!-- Argon CSS -->
  <link type="text/css" href="assets/css/argon.css?v=1.1.0" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Mansalva&display=swap" rel="stylesheet">
</head>
<?php include 'navbar.php'; ?>
  <main>
    <section class="section section-shaped section-lg">
      <div class="shape shape-style-1 bg-gradient-default">
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
      </div>
      <div class="container pt-lg-md" id="stylebar" style="overflow-y: scroll; margin-left: auto;margin-right: auto;   ">
        <div class="row justify-content-center">
          <div class="col-lg-12">
            <div class="card bg-secondary shadow border-0">
              <!-- <div class="card-header bg-white pb-5">
                <div class="text-muted text-center mb-3"><small>Sign up with</small></div>
                <div class="text-center">
                  <a href="#" class="btn btn-neutral btn-icon mr-4">
                    <span class="btn-inner--icon">
                      <img src="../assets/img/icons/common/github.svg" alt="image">
                    </span>
                    <span class="btn-inner--text">Github</span>
                  </a>
                  <a href="#" class="btn btn-neutral btn-icon">
                    <span class="btn-inner--icon">
                      <img src="../assets/img/icons/common/google.svg" alt="image">
                    </span>
                    <span class="btn-inner--text">Google</span>
                  </a>
                </div>
              </div>
               --><div class="card-body px-lg-5 py-lg-5" >
                <div class=" text-muted mb-4">
                  <div class="container"  >
    <h1 style="text-align: center;border-bottom: 3px double;font-family: 'Cinzel', serif; ">About SWIRLLY</h1>
    <div class="row" >
      
     <div class="text-center col sm 6">
         <!-- <img class="align-middle m-5"  src="assets/img/brand/What-Is-Scribe-Image.png"> -->
         <img src="assets/img/brand/Swirlly.png"  class="responsive" >
     </div>
     <div class="col sm 4">
             <h2 class="mx-5 my-5">Our  Motto <br>What we want to do!</h2>
             <h6 class="mx-5 my-1 ">
               We are making a platform for helping <br>
               the people who are creative and can’t <br>
               gain what they mean to earn!<br><br>
               Our team are dedicated to provide a delightful experience <br>
               to our valuable customers and sellers.
         </h6>
     </div>
     </div>
   <hr>
   <div class="row">
     <div class="col sm 6 text-right pt-5 vertical-divider">
         <h1>You Need, We Make!!!</h1>
       <h4>“OUR THIS STEP IS TO DECREASE THE INFLATION AND BRING THE CREATIVE ARTIST TO BE KNOWN TO THE WORLD.”</h4>
         
     </div>
     <div class="text-center col sm 4">
       
       <img  src="assets/img/brand/WhatsApp%20Image%202020-02-09%20at%207.58.13%20PM.jpeg
" class="responsive" >
       
     </div>
   </div>
   <hr>
   <div class="row">
       <div class="col sm 4 text-center vertical-divider">
          <h3>Creative sellers</h3>
          <h6>If you know you can make creative items (which is related to foods, dresses, decorative things) then believe in “SWIRLLY” to bring your creativeness worldwide.</h6>
       </div>
       <div class="col sm 4 text-center vertical-divider">
           <h3>Valuable customers</h3>
           <h6>If you want to try the creativity of your city then try the products sells on “SWIRLLY”. Once you try our product you would come to know how creative your neighborhood is! And you will come to love with the low prize and best products.</h6>
       </div>
       <div class="col sm 4 text-center">
           <h3>Our services</h3>
           <h6>By providing the delivery service we would like to save your precious time and like to spread our love through our amazing products.</h6>
       </div>
     </div>
     <hr>
     <div style="padding: 12px">
         <h1 class="text-center">How do we work?</h1>
        <h5> 1. The vendor has to register in our application.
           (If  you are interested in selling your hand made product through swirlly please register your name in this link……..)<br><br>
           2.Vendor(seller) then put their products picture on our application with the price. (For handmade they will  going to put their designs picture in the application then will stitch the dress according to the customer requirement.)<br><br>
           3.Now from here the customer task is start; they just have to order what product they are interested in, and place the order for their desire product with the suitable prices which are satisfying for them. (for the dresses they have to first choose the design of their choice and has to place order for having the dresses.)<br><br>
           4.Customers are free to select the seller from whom they have to buy the product.<br><br>
           5.Deliveries are available but not compulsory, if you prefer self service you are mostly welcome.<br><br>
           6.And about delivery the delivery for food dishes like (pickle, pappad, etc kinds of restorable items) and dresses will be delivered according to the seller.<br><br>
           7. while the normal food item like Tiffin, etc will delivered in 30 minutes or according to the distance between seller and customers.</h5>
           </div>
     <a href="register.php" class="btn btn-block btn-outline-primary">SELL ON SWIRLLY</a>
  </div>
                            </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>
<?php include 'footer.php' ?>
  <!-- Core -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/popper/popper.min.js"></script>
  <script src="assets/vendor/bootstrap/bootstrap.min.js"></script>
  <script src="assets/vendor/headroom/headroom.min.js"></script>
  <!-- Argon JS -->
  <script src="assets/js/argon.js?v=1.1.0"></script>

</body>

</html>
