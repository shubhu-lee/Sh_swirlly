
<!----------Include Bootstrap Links------->
<?php include 'nav.php'?>

<!--------- Button ----------->
<center><button href="#" data-toggle="modal" data-target="#add_product_modal" onclick="show_img(/*<?php echo $row['pid']?>*/)"  class="btn btn-primary btn-sm">Show Images</button></center>


<!----------- Pop Up Div ---------->
<div id="show_img_div" hidden>
    <div class="modal fade" id="add_product_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Product</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
   <!--      Dynamic Image view Div START -->
        <div id="inner"></div>     
   <!--      Dynamic Image view Div END -->     
      </div>
    </div>
  </div>
</div>
</div>

<script type="text/javascript">
  function show_img(pid){
  const div = document.getElementById('show_img_div');
  
  div.hidden=false;
            $.ajax({
      url: 'show_img.php',
      type: 'POST',
      data: {
        'show': 1,
        'pid': pid,
        
      },
      error: function (data){
        $('#inner').html('<h3 style="color:red">Error loading Images!</h3>');
        
      },
      success: function(data){
          $('#inner').html(data);
        
      }
    });

  }
</script>