<?php 
 
  include 'dbconnect.php';
  

  if(isset($_POST['register'])){
$first_name='';
     $name = $_POST['name'];
     $email = $_POST['email'];
     $mobile = $_POST['mobile'];
     $password = $_POST['password'];

      
  
     //existing email address in our database
  $sql = "SELECT vid FROM vendor_registration_tbl WHERE vemail = '$email' LIMIT 1" ;
  $check_query = mysqli_query($con,$sql);
  $count_email = mysqli_num_rows($check_query);
  if($count_email > 0){
    echo "
      
        <script>
          alert('Email Address is already in Use!!');
          window.location.href = 'login.php';
        </script>
      
    ";

    exit();
  }
  else{
     $password = md5($password); 
     $sql = "INSERT INTO `vendor_registration_tbl`(`vname`, `vemail`, `vmobile`, `vpassword`) VALUES ('$name','$email','$mobile','$password')";
     if(mysqli_query($con,$sql)){
          echo'<script>
              alert("Successfully Registered!!");
          </script>';
           
           
           

     }
   }
  }



?>
<!--

=========================================================
* Argon Design System - v1.1.0
=========================================================

* Product Page: https://www.creative-tim.com/product/argon-design-system
* Copyright 2019 Creative Tim (https://www.creative-tim.com)
* Licensed under MIT (https://github.com/creativetimofficial/argon-dashboard/blob/master/LICENSE.md)

* Coded by Creative Tim

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software. -->
<!DOCTYPE html>
<html lang="en">
<head>
  
  <title>Register Here</title>
  
</head>

<body>
  <?php include 'navbar.php'; ?>
  <main>
    <section class="section section-shaped section-lg">
      <div class="shape shape-style-1 bg-gradient-default">
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
      </div>
      <div class="container pt-lg-md">
        <div class="row justify-content-center">
          <div class="col-lg-5">
            <div class="card bg-secondary shadow border-0">
              <!-- <div class="card-header bg-white pb-5">
                <div class="text-muted text-center mb-3"><small>Sign up with</small></div>
                <div class="text-center">
                  <a href="#" class="btn btn-neutral btn-icon mr-4">
                    <span class="btn-inner--icon">
                      <img src="../assets/img/icons/common/github.svg" alt="image">
                    </span>
                    <span class="btn-inner--text">Github</span>
                  </a>
                  <a href="#" class="btn btn-neutral btn-icon">
                    <span class="btn-inner--icon">
                      <img src="../assets/img/icons/common/google.svg" alt="image">
                    </span>
                    <span class="btn-inner--text">Google</span>
                  </a>
                </div>
              </div>
               --><div class="card-body px-lg-5 py-lg-5">
                <div class="text-center text-muted mb-4">
                  <h3>Create your Seller Account</h3>
                </div>
                <form method="post" >
                  <div class="form-group">
                    <div class="input-group input-group-alternative mb-3">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="ni ni-hat-3"></i></span>
                      </div>
                      <input required class="form-control" id="name" placeholder="Full Name" name="name" type="text">
                    </div>
                  </div>

                  <div class="form-group">
                    <div class="input-group input-group-alternative mb-3">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="ni ni-email-83"></i></span>
                      </div> 
                      <input required class="form-control" id="email" placeholder="Email" name="email" type="email">
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="input-group input-group-alternative mb-3">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="ni ni-mobile-button"></i></span>
                      </div>
                      <input required class="form-control" id="mobile" placeholder="Mobile" name="mobile" type="number">
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="input-group input-group-alternative">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="ni ni-lock-circle-open"></i></span>
                      </div>
                      <input required class="form-control" id="password" onkeyup='check();'  placeholder="Password" name="password" type="password">
                    </div>
                  </div>
                  <div id='boxxx' class="form-group " >
                    <div  class="input-group input-group-alternative ">
                      <div   class="input-group-prepend">
                        <span  class="input-group-text"><i class="ni ni-lock-circle-open"></i></span>
                      </div>
                      <input required class="form-control " id="confirm_password" onkeyup='check();'   placeholder="Confirm Password" name="ConfirmPassword" type="password">
                    </div>
                     
                  </div>
                  <!-- <div class="text-muted font-italic"><small>password strength: <span class="text-success font-weight-700">strong</span></small></div> -->
                  <div class="row my-4">
                    <div class="col-12">
                      <div class="custom-control custom-control-alternative custom-checkbox">
                        <input required class="custom-control-input" id="customCheckRegister" type="checkbox">
                        <label class="custom-control-label" for="customCheckRegister"><span>I agree with the <a href="Swirlly_Policy.php">Privacy Policy</a></span></label>
                      </div>
                    </div>
                  </div>
                  <div class="text-center">
                    <button  name="register"  id="ena" class="btn btn-primary mt-4">Create account</button>
                  </div>
                </form>
              </div>
            </div>
          </div>

        </div>
      </div>
        <br><br>
    </section>
  </main>
<?php include 'footer.php' ?>
  <!-- Core -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/popper/popper.min.js"></script>
  <script src="assets/vendor/bootstrap/bootstrap.min.js"></script>
  <script src="assets/vendor/headroom/headroom.min.js"></script>
  <!-- Argon JS -->
  <script src="assets/js/argon.js?v=1.1.0"></script>
  
</body>

</html>
    
<script type="text/javascript">
  /*Password Validation Start*/
  var check = function() {

  if (document.getElementById('password').value === document.getElementById('confirm_password').value) {
    /*document.getElementById('confirm_password').style.backgroundColor = '#7bed9f';*/
    /*console.log(document.getElementById('password').value);
    console.log(document.getElementById('confirm_password').value);*/

    var element = document.getElementById("boxxx");
    element.className ='has-success';
     document.getElementById('confirm_password').className ='form-control is-valid';
  } 
  else {
    /*document.getElementById('confirm_password').style.backgroundColor = '#ff6b81';*/
      /*console.log(document.getElementById('password').value);
    console.log(document.getElementById('confirm_password').value);*/
    var element = document.getElementById("boxxx");
    
     element.className ='has-danger';
    
  }
}
/*Password Validation End*/

let inputs = document.querySelectorAll('input'),
    knapp = document.querySelector('#ena')
    knapp.disabled = true
    if(document.getElementById('customCheckRegister').checked == true){
      console.log("hey");
    }
for (i = 0; i < inputs.length; i++) {
  inputs[i].addEventListener('input',() => {
    let values = []
    inputs.forEach(v => values.push(v.value))
    knapp.disabled = values.includes('')
  })
}
  
</script>

