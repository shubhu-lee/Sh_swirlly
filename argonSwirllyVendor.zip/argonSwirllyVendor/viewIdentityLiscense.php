<?php
		session_start();
		include 'dbconnect.php';
		
		 $type = $_GET['type'];
		

    			
    			 $sql1 = "SELECT * from vendor_registration_tbl LEFT JOIN vendor_details_tbl ON (vendor_registration_tbl.vid = vendor_details_tbl.vid) WHERE vendor_registration_tbl.vid = $_SESSION[vid] UNION ALL SELECT * from vendor_registration_tbl RIGHT JOIN vendor_details_tbl ON (vendor_registration_tbl.vid = vendor_details_tbl.vid) WHERE vendor_registration_tbl.vid = $_SESSION[vid] LIMIT 0,1";
    			/*$sql2 = "SELECT *   FROM `moredetails`  WHERE v_id = $vid " ;*/
        		
    			$result1 = mysqli_query($con, $sql1);
    			/*$result2 = mysqli_query($con, $sql2);*/
                while ($row1 = mysqli_fetch_assoc($result1)) {  
                if($type == 'identity') {     
                		if(!$row1['identityproof'] == ''){ 
	                   		echo '<div>
	                   				<img style="padding:12px"  src="'.$row1["identityproof"].'">
	                   			</div>';
	                   			
	                   		 } 
	                   		else { 
	                   			echo'<div class="form-group">
	                            <label for="mobile"><b>Identity Proof:</b></label>
	                            <input type="file" name="identity" class="">
	                   		</div>';
	                   			
	                   			 } }

	                   			 	if($type == 'foodlicense'){
	                   			 if($row1['liscense'] == ''){ 
	                   		echo '
	                   		<div class="form-group">
	                            <label for="mobile"><b>Food License(If Dealing with Food ):</b></label>
	                            <input type="file" name="fssi" class="">
	                   		</div>'; }
	                   		else{
	                   			echo '<div>
	                   				<img style="padding:12px"  src="'.$row1["liscense"].'">
	                   			</div>';
	                   			

	                   		}}

	                   			}

 ?>