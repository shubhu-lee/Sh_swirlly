<?php 

	 $request = $_SERVER['REQUEST_METHOD'];
	 $response = array();
	
	switch($request){

		case "GET":
			response(doGet());
		break;

		case "POST":
			response(doPost());
		break;

		case "DELETE":
			response(doDelete());
		break;

		case "PUT":
			response(doPut());
		break;

	}

	function doGet(){

		if(@$_GET['id']){
			@$id = $_GET['id'];
			$where = "WHERE `vid`=".$id;
		}else{
			$id = 0;
			$where = NULL;
		}

		$dbConnect = mysqli_connect("localhost","root","","swirllyDB");
		$query = mysqli_query($dbConnect,"SELECT * FROM `vendor_registration_tbl`".$where);
		
		while($data = mysqli_fetch_assoc($query)){

			$response[] = array('id' => $data['vid'],'name' => $data['vname'],'email' => $data['vemail'],'mobile' => $data['vmobile'],'password' => $data['vpassword']);

		}
		return $response;
	}

	function doPost(){
		if($_POST){
			$dbConnect = mysqli_connect("localhost","root","","swirllyDB");
			echo("HEY");
			$query = mysqli_query($dbConnect,"INSERT INTO `vendor_registration_tbl`(`vname`, `vemail`, `vmobile`, `vpassword`) VALUES('".$_POST['vname']."','".$_POST['vemail']."','".$_POST['vmobile']."','".$_POST['vpassword']."')");

			if($query == true){
				echo $response = array("message" => "Success");
			}
			else{
				echo $response	 = array("message" => "Failed");
			}
			return $response;	
		}
		
	}

	function doDelete(){
		echo("DELETE CALLED");
	}
	function doPut(){
		echo("PUT CALLED");
	}

	function response($response){
		echo json_encode(array("status" => "200", "data" => $response));
	}

?>