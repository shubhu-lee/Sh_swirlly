
<?php
session_start();
include 'dbconnect.php';

$target_dir = "uploadsdocs/";
$target_file1 = $target_dir . basename($_FILES["identity"]["name"]);
$target_file2 = $target_dir . basename($_FILES["fssi"]["name"]);
$uploadOk = 1;
$imageFileType1 = strtolower(pathinfo($target_file1,PATHINFO_EXTENSION));
$imageFileType2 = strtolower(pathinfo($target_file2,PATHINFO_EXTENSION));
// Check1 if image file is a actual image or fake image
if(isset($_POST["update"])) {
    //getting address
    $address = $_POST['address'];
;    $check1 = getimagesize($_FILES["identity"]["tmp_name"]);
     $check2 = getimagesize($_FILES["fssi"]["tmp_name"]);
    if($check1 !== false AND $check2 !== false) {
        echo "File is an image - " . $check1["mime"] . ".";
        echo "File is an image - " . $check2["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
}
// Check1 if file already exists
if (file_exists($target_file1) OR file_exists($target_file2)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}
// Check1 file size
if ($_FILES["identity"]["size"] > 50000000000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType1 != "jpg" && $imageFileType1 != "png" && $imageFileType1 != "jpeg"
&& $imageFileType1 != "gif" && $imageFileType2 != "jpg" && $imageFileType2 != "png" && $imageFileType2 != "jpeg" && $imageFileType2 != "gif" ) {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
// Check1 if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["identity"]["tmp_name"], $target_file1) AND move_uploaded_file($_FILES["fssi"]["tmp_name"], $target_file2)) 
    {

        echo $path1 = $target_dir . basename( $_FILES["identity"]["name"]);
        echo $path2 = $target_dir . basename( $_FILES["fssi"]["name"]);
        echo "The file ". basename( $_FILES["identity"]["name"]). " has been uploaded.";
        echo "The file ". basename( $_FILES["fssi"]["name"]). " has been uploaded.";

        echo $sql = "INSERT INTO `vendor_details_tbl` (`vid`, `vaddress`, `identityproof`, `liscense`) VALUES ('$_SESSION[vid]','$address','$path1' , '$path2')";
        if(mysqli_query($con,$sql)){
            echo" <script>
            alert('SUCCESSFULLY UPLOADED');
            window.location.href='profile.php?vid=".$_SESSION['vid']."';
            </script>";

        }
    } 
    else {
        echo "Sorry, there was an error uploading your file.";
    }
}
?>
