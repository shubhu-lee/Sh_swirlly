<?php session_start(); ?>
  


<!--

=========================================================
* Argon Design System - v1.1.0
=========================================================

* Product Page: https://www.creative-tim.com/product/argon-design-system
* Copyright 2019 Creative Tim (https://www.creative-tim.com)
* Licensed under MIT (https://github.com/creativetimofficial/argon-dashboard/blob/master/LICENSE.md)

* Coded by Creative Tim

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software. -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Start your development with a Design System for Bootstrap 4.">
  <meta name="author" content="Creative Tim">
  <title>Sell On Swirlly</title>
  <!-- Favicon -->
  <link href="./assets/img/brand/Swirlly.png" rel="icon" type="image/png">
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  <link href="./assets/vendor/nucleo/css/nucleo.css" rel="stylesheet">
  <link href="./assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <!-- Argon CSS -->
  <link type="text/css" href="./assets/css/argon.css?v=1.1.0" rel="stylesheet">
  
</head>

<body>
  <?php include 'navbar.php'; ?>
  <main>
    <!--

=========================================================
* Argon Design System - v1.1.0
=========================================================

* Product Page: https://www.creative-tim.com/product/argon-design-system
* Copyright 2019 Creative Tim (https://www.creative-tim.com)
* Licensed under MIT (https://github.com/creativetimofficial/argon-dashboard/blob/master/LICENSE.md)

* Coded by Creative Tim

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software. -->
    <div class="position-relative">
      <!-- Hero for FREE version -->
      <section class="section section-lg section-hero section-shaped">
        <!-- Background circles -->
        <div class="shape shape-style-1 shape-primary">
          <span class="span-150"></span>
          <span class="span-50"></span>
          <span class="span-50"></span>
          <span class="span-75"></span>
          <span class="span-100"></span>
          <span class="span-75"></span>
          <span class="span-50"></span>
          <span class="span-100"></span>
          <span class="span-50"></span>
          <span class="span-100"></span>
        </div>
        <!-- <div class="container shape-container d-flex align-items-center py-lg">
          <div class="col px-0">
            <div class="row align-items-center justify-content-center">
              <div class="col-lg-6 text-center">
                <img alt="image" src="./assets/img/brand/white.png" style="width: 200px;" class="img-fluid">
                <p class="lead text-white">A beautiful Design System for Bootstrap 4. It's Free and Open Source.</p>
                <div class="btn-wrapper mt-5">
                  <a href="https://www.creative-tim.com/product/argon-design-system" class="btn btn-lg btn-white btn-icon mb-3 mb-sm-0">
                    <span class="btn-inner--icon"><i class="ni ni-cloud-download-95"></i></span>
                    <span class="btn-inner--text">Download HTML</span>
                  </a>
                  <a href="https://github.com/creativetimofficial/argon-design-system" class="btn btn-lg btn-github btn-icon mb-3 mb-sm-0" target="_blank">
                    <span class="btn-inner--icon"><i class="fa fa-github"></i></span>
                    <span class="btn-inner--text"><span class="text-warning">Star us</span> on Github</span>
                  </a>
                </div>
                <div class="mt-5">
                  <small class="text-white font-weight-bold mb-0 mr-2">*proudly coded by</small>
                  <img alt="image" src="./assets/img/brand/creativetim-white-slim.png" style="height: 28px;">
                </div>
              </div>
            </div>
          </div>
        </div>
         -->
         <div class="container shape-container d-flex align-items-center py-lg">
          <div class="col px-0">
            <div class="row align-items-center justify-content-center">
              <div class="col-lg-6 text-center">
                <img alt="image" src="./assets/img/brand/Swirlly.png" style="width: 200px;" class="img-fluid">
                <p style="font-size: 24px" class="lead text-white"><b>Sell to crores of customers on Swirlly, right from your doorstep</b></p>
                
                <div class="btn-wrapper mt-5">
                  <!-- <a href="https://www.creative-tim.com/product/argon-design-system" class="btn btn-lg btn-white btn-icon mb-3 mb-sm-0">
                    <span class="btn-inner--icon"><i class="ni ni-cloud-download-95"></i></span>
                    <span class="btn-inner--text">Download HTML</span>
                  </a>
                  <a href="https://github.com/creativetimofficial/argon-design-system" class="btn btn-lg btn-github btn-icon mb-3 mb-sm-0" target="_blank">
                    <span class="btn-inner--icon"><i class="fa fa-github"></i></span>
                    <span class="btn-inner--text"><span class="text-warning">Star us</span> on Github</span>
                  </a> -->
                  <p class="lead text-white">How will this information be used?
                      You can use your email address or mobile number as 'Username' to login to your Swirlly Seller Account. Please note, the 'Username' and 'Password' used here are only to access your Swirlly Seller Account and can’t be used on Swirlly.com shopping destination.</p>
                </div>
                <div>
                  <li class="nav-item  d-lg-block ml-lg-4">
              <a href="login.php" target="" class="btn btn-neutral btn-icon">
                <span class="btn-inner--icon">
                  <i class="fa fa-user mr-2"></i>
                </span>
                <span class="nav-link-inner--text">Login</span>
              </a>
            </li><br>
            <li class="nav-item  d-lg-block ml-lg-4">
              <a href="register.php" target="" class="btn btn-neutral btn-icon">
                <span class="btn-inner--icon">
                  <i class="fa fa-user mr-2"></i>
                </span>
                <span class="nav-link-inner--text">Register as a Seller</span>
              </a>
            </li>
                </div>
                <!-- <div class="mt-5">
                  <small class="text-white font-weight-bold mb-0 mr-2">*proudly coded by</small>
                  <img alt="image" src="./assets/img/brand/creativetim-white-slim.png" style="height: 28px;">
                </div> -->
              </div>
            </div>
          </div>
        </div>
         <!-- SVG separator -->
        <div class="separator separator-bottom separator-skew zindex-100">
          
        </div>
      </section>
    </div>
  </main>
  <?php include 'footer.php' ?>
  <!-- Core -->
  <script src="./assets/vendor/jquery/jquery.min.js"></script>
  <script src="./assets/vendor/popper/popper.min.js"></script>
  <script src="./assets/vendor/bootstrap/bootstrap.min.js"></script>
  <script src="./assets/vendor/headroom/headroom.min.js"></script>
  <!-- Optional JS -->
  <script src="./assets/vendor/onscreen/onscreen.min.js"></script>
  <script src="./assets/vendor/nouislider/js/nouislider.min.js"></script>
  <script src="./assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
  <!-- Argon JS -->
  <script src="./assets/js/argon.js?v=1.1.0"></script>
</body>

</html>
