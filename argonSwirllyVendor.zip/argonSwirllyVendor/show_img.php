<?php 
  session_start();
  include 'dbconnect.php';
  if (!$con) {
    die('Connection failed ' . mysqli_error($con));
  }else{/*echo 'connect<br>';*/}
  

   if (isset($_POST['show'])) {
   $pid = $_POST['pid'];
    
$query = mysqli_query($con , "SELECT p_image1,p_image2,p_image3,p_image4,image1_status,image2_status,image3_status,image4_status FROM product_tbl WHERE pid = $pid AND vid = $_SESSION[vid]");

$row = mysqli_fetch_assoc($query);
$status1 = $row['image1_status'];
$status2 = $row['image2_status'];
$status3 = $row['image3_status'];
$status4 = $row['image4_status'];

if ($status1==1) {
    $status1_toggle='';
    $btn1_verify_toggle='hidden'; 
    $btn1_unverify_toggle='';
    $img1_status='border:5px solid green';
  }
  elseif ($status1==0) {
   $status1_toggle='hidden';
   $btn1_verify_toggle='';
   $btn1_unverify_toggle='hidden';
   $img1_status='border:5px solid red';


  }
if ($status2==1) {
    $status2_toggle='';
    $btn2_verify_toggle='hidden'; 
    $btn2_unverify_toggle='';
    $img2_status='border:5px solid green';
  }
  elseif ($status2==0) {
   $status2_toggle='hidden';
   $btn2_verify_toggle='';
   $btn2_unverify_toggle='hidden';
   $img2_status='border:5px solid red';

  }
if ($status3==1) {
    $status3_toggle='';
    $btn3_verify_toggle='hidden'; 
    $btn3_unverify_toggle='';
    $img3_status='border:5px solid green';
  }
  elseif ($status3==0) {
   $status3_toggle='hidden';
   $btn3_verify_toggle='';
   $btn3_unverify_toggle='hidden';
   $img3_status='border:5px solid red';

  }
if ($status4==1) {
    $status4_toggle='';
    $btn4_verify_toggle='hidden'; 
    $btn4_unverify_toggle='';
    $img4_status='border:5px solid green';
  }
  elseif ($status4==0) {
   $status4_toggle='hidden';
   $btn4_verify_toggle='';
   $btn4_unverify_toggle='hidden';
   $img4_status='border:5px solid red';

  }
http://localhost/Swirlly/admin
$ver1 = "'chang1','image1_status',$pid,'bt1','img1_style'";
$ver2 = "'chang2','image2_status',$pid,'bt2','img2_style'";
$ver3 = "'chang3','image3_status',$pid,'bt3','img3_style'";
$ver4 = "'chang4','image4_status',$pid,'bt4','img4_style'";
$string='
      <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <!-- Image Start -->
      <img id="img1_style"  class="d-block w-100" src="'.$row["p_image1"].'"><br> <div style="margin-left:1px" class="row"> <h5 style="color:green" '.$status1_toggle.' >Verified</h5>&nbsp;&nbsp;<div '.$status1_toggle.' class="check"></div></div>
      


    </div>
    <div class="carousel-item">
      <img id="img2_style"  class="d-block w-100" src="'.$row["p_image2"].'"><br><div style="margin-left:1px" class="row"> <h5 style="color:green" '.$status2_toggle.' >Verified</h5>&nbsp;&nbsp;<div '.$status2_toggle.' class="check"></div></div>
      
      
    </div>
    <div class="carousel-item">
      <img id="img3_style"  class="d-block w-100" src="'.$row["p_image3"].'"><br><div style="margin-left:1px" class="row"> <h5 style="color:green" '.$status3_toggle.' >Verified</h5>&nbsp;&nbsp;<div '.$status3_toggle.' class="check"></div></div>
      
    </div>
    <div class="carousel-item">
      <img id="img4_style"  class="d-block w-100" src="'.$row["p_image4"].'"><br><div style="margin-left:1px" class="row"> <h5 style="color:green" '.$status4_toggle.' >Verified</h5>&nbsp;&nbsp;<div '.$status4_toggle.' class="check"></div></div>
      
    <!-- Image End -->

  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
    

  ';


echo $string;




exit();




}
?>

<!-- 
<center><div id="chang2">
<button '.$btn2_verify_toggle.' id="bt2" class="btn btn-success" onclick="verify_img('."$ver2".')">Verify</button>
      <button '.$btn2_unverify_toggle.' id="bt2" class="btn btn-danger" onclick="verify_img('."$ver1".')">UnVerify</button></div></center>

      <center><div id="chang3">
      <button '.$btn3_verify_toggle.' id="bt3" class="btn btn-success" onclick="verify_img('."$ver3".')">Verify</button>
      <button '.$btn3_unverify_toggle.' id="bt3" class="btn btn-danger" onclick="verify_img('."$ver1".')">UnVerify</button></div></center> 


-->