<?php 
  
    session_start();
    include 'dbconnect.php';
     if(!isset($_SESSION['vid'])){

    echo "<script>
        window.location.href = 'index.php';
    </script>";

    } 
     if(isset($_SESSION['vid'])){

      $query = "SELECT * FROM product_tbl WHERE vid = $_SESSION[vid] ";
              $sql = mysqli_query($con,$query);
               
                
              $counter = 1;
                
               

?>

<!--

=========================================================
* Argon Design System - v1.1.0
=========================================================

* Product Page: https://www.creative-tim.com/product/argon-design-system
* Copyright 2019 Creative Tim (https://www.creative-tim.com)
* Licensed under MIT (https://github.com/creativetimofficial/argon-dashboard/blob/master/LICENSE.md)

* Coded by Creative Tim

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software. -->
<!DOCTYPE html>
<html lang="en">
<head>
  <?php include 'navbar.php'; ?>
  <title>View Products</title>
  <style>
    a.class {color:black;}
a{
  color: black;
}
.button{
  padding-left: 750px;
  padding-bottom: 10px;
  text-decoration: none;
  }
  </style>


</head>

<body>
  <main class="profile-page">
    <section class="section-profile-cover section-shaped my-0">
      <!-- Circles background -->
      <div class="shape shape-style-1 shape-primary alpha-4">
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
      </div>
      <!-- SVG separator -->
      <div class="separator separator-bottom separator-skew">
        <!-- <svg x="0" y="0" viewBox="0 0 2560 100" preserveAspectRatio="none" version="1.1" xmlns="http://www.w3.org/2000/svg">
          <polygon class="fill-white" points="2560 0 2560 100 0 100"></polygon>
        </svg> -->
      </div>
    </section>
    <section class="section" >
      <div class="container" >
        <div class="card card-profile shadow mt--300">
          <div class="container" style="overflow-x:auto;">
 
  <table class="table" >
    <?php if(mysqli_num_rows($sql) > 0){ ?>
    <thead>
      <tr>
        <th>Sr. No</th>
        <th>Product Name</th>
        <th>Price</th>
        <th>Images</th>
        <th>Status</th>
        <th>View Details</th> 
        <th>Delete</th>
        
      </tr>
    </thead>
    <?php 
     
    while($row = mysqli_fetch_assoc($sql))
              {   

                ?>
    <tbody>
     <tr>
        <td><?php echo $counter ?></td>
        <td> <a href="singleproduct.php?pid=<?php echo $row['pid']  ?>" class="class"><?php echo $row['p_name'] ?></a></td>
        <td><?php echo $row['p_price'] ?></td>
        <td><button data-toggle="modal" data-target="#add_product_modal" class="btn btn-block btn-primary" onclick="show_img('<?php echo $row['pid']?>')">Show Images</button></td>
        <td><div>
                  <?php if($row['status'] == 1){?>
                    <div class="btn btn-block btn-success">Active</div>
                  <?php }
                    else{
                   ?>
                    <div class="btn btn-block btn-danger">Not Active</div>
                  <?php  } ?>
                </div></td>

                <td><div>
                  <?php if($row['status'] == 1){?>
                    <div class="btn btn-block btn-dark">N.A</div>
                  <?php }
                    else{
                   ?>
                    <a href="singleproduct.php?pid=<?php echo $row['pid']  ?>"><button name="edit" class="btn btn-block btn-success"><span class="fa fa-file"></span></button></a>
                  <?php  } ?>
                </div>


                  </td>

                <td><div>
                  <?php if($row['status'] == 1){?>
                    <div class="btn btn-block btn-dark">N.A</div>
                  <?php }
                    else{
                   ?>
                    <button onclick="ConfirmDelete(<?php echo $row['pid'] ?>);" name="delete" class="btn btn-block btn-danger"><span class="fa fa-trash"></span></button>
                  <?php  } ?>
                </div>

                  </td>

              

      </tr>
     
      
    </tbody>
  </table>
     <div class="button">
      <a href="addproducts.php"><button type="button" class="btn btn-1 btn-outline-primary" style="width: 200px;">ADD Products</button></a>
    </div>
    <table>
   <?php $counter++; } }
   
      else{
            echo '<center><h1>No Product(s) Found!</h1><br>
            <h2>Please Add Product(s) Here</h2><br>
            <a class="btn btn-danger" href="addproducts.php" class="nav-link" class="btn" style="color: white;">Add Products</a>
            </center>';
          } ?>     
  </table>     

</div>
    </section>
    
  </main>
  <?php include 'footer.php'; ?>
  <!-- Core -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/popper/popper.min.js"></script>
  <script src="assets/vendor/bootstrap/bootstrap.min.js"></script>
  <script src="assets/vendor/headroom/headroom.min.js"></script>
  <!-- Argon JS -->
  <script src="assets/js/argon.js?v=1.1.0"></script>
</body>

</html>

<?php } ?>
<!----------- Pop Up Div ---------->
<div id="show_img_div" >
    <div class="modal fade" id="add_product_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <!-- <h5 class="modal-title" id="exampleModalLabel">Add Product</h5> -->
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
   <!--      Dynamic Image view Div START -->
        <div id="inner"></div>     
   <!--      Dynamic Image view Div END -->     
      </div>
    </div>
  </div>
</div>
</div>

<script type="text/javascript">
  function show_img(pid){
    console.log(pid);
  const div = document.getElementById('show_img_div');
  
  
            $.ajax({
      url: 'show_img.php',
      type: 'POST',
      data: {
        'show': 1,
        'pid': pid
        
      },
      error: function (data){
        $('#inner').html('<h3 style="color:red">Error loading Images!</h3>');
        
      },
      success: function(data){
          $('#inner').html(data);
        
      }
    });

  }
  function ConfirmDelete(pid){
    var x = confirm("Are You Sure Want To Delete?");
    
    if(x){
    $.ajax({
      url: 'deleteproduct.php',
      type: 'POST',
      data: {
        'delete': 1,
        'pid': pid
        
      },
      error: function (data){
        console.log(data);
        
      },
      success: function(data){
          alert(data);
          console.log(data);
          location.reload(true);
        
      }
    });

  }
  else{
    alert("Error in Deleting Product");
  }
}

</script>
