<?php 

  session_start();
  if(!isset($_SESSION['vid'])){

    echo "<script>
        window.location.href = 'index.php';
    </script>";

    } 

  if(isset($_SESSION['vid'])){

?>


<!--

=========================================================
* Argon Design System - v1.1.0
=========================================================

* Product Page: https://www.creative-tim.com/product/argon-design-system
* Copyright 2019 Creative Tim (https://www.creative-tim.com)
* Licensed under MIT (https://github.com/creativetimofficial/argon-dashboard/blob/master/LICENSE.md)

* Coded by Creative Tim

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software. -->
<!DOCTYPE html>
<html lang="en">
<head>
  <?php include 'navbar.php'; ?>
  <title>Add Products</title>
  
</head>

<body>
  <main class="profile-page">
    <section class="section-profile-cover section-shaped my-0">
      <!-- Circles background -->
      <div class="shape shape-style-1 shape-primary alpha-4">
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
      </div>
      <!-- SVG separator -->
      <div class="separator separator-bottom separator-skew">
        <svg x="0" y="0" viewBox="0 0 2560 100" preserveAspectRatio="none" version="1.1" xmlns="http://www.w3.org/2000/svg">
          <polygon class="fill-white" points="2560 0 2560 100 0 100"></polygon>
        </svg>
      </div>
    </section>
    <section class="section">
      <div class="container">
        <div class="card card-profile shadow mt--300">
          <div class="px-4">
            <div class="row justify-content-center">
            <div class="text-center mt-5">
              <h3>Add Product(s)</h3>
              <form  method="post" enctype="multipart/form-data" action="uploadproducts.php">
                <div class="form-group">
                    <div class="input-group input-group-alternative mb-3">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="ni ni-cart"></i></span>
                      </div>
                      <input required class="form-control"  placeholder="Product Name" name="product_name" type="text">
                    </div>
                  </div>
                  <div class="input-group input-group-alternative mb-3">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="ni ni-image"></i></span>
                      </div>
                      <input  class="form-control"   name="product1" type="file">
                  </div>
                  <div class="input-group input-group-alternative mb-3">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="ni ni-image"></i></span>
                      </div>
                      <input  class="form-control"   name="product2" type="file">
                  </div>
                  <div class="input-group input-group-alternative mb-3">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="ni ni-image"></i></span>
                      </div>
                      <input  class="form-control"   name="product3" type="file">
                  </div>
                  <div class="input-group input-group-alternative mb-3">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="ni ni-image"></i></span>
                      </div>
                      <input  class="form-control custom-file-upload "   name="product4" type="file">
                  </div>
                  <div ><small style="color:red">The Images should be in JPEG/JPG fromat only*</small></div><br>
                  <div class="input-group input-group-alternative mb-3">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fa fa-inr"></i></span>
                      </div>
                      <input required class="form-control"  placeholder="Price" name="product_price" type="number">
                  </div>
                  <div class="input-group input-group-alternative mb-3">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fa fa-book"></i></span>
                      </div>
                      <textarea  required name="description" class="form-control" placeholder="Enter Product Description..."></textarea>
                  </div>
                  <div class="text-center">
                    <button  name="add"    class="btn btn-primary mt-4">Add</button>
                     

                    
                
              </form>
              <a href="viewproducts.php"><button class="btn btn-success mt-4">View Products</button></a>
            </div><br><br>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>
  <?php include 'footer.php'; ?>
  <!-- Core -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/popper/popper.min.js"></script>
  <script src="assets/vendor/bootstrap/bootstrap.min.js"></script>
  <script src="assets/vendor/headroom/headroom.min.js"></script>
  <!-- Argon JS -->
  <script src="assets/js/argon.js?v=1.1.0"></script>
</body>

</html>
<?php } ?>