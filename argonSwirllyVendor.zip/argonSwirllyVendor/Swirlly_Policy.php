
<!--

=========================================================
* Argon Design System - v1.1.0
=========================================================

* Product Page: https://www.creative-tim.com/product/argon-design-system
* Copyright 2019 Creative Tim (https://www.creative-tim.com)
* Licensed under MIT (https://github.com/creativetimofficial/argon-dashboard/blob/master/LICENSE.md)

* Coded by Creative Tim

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software. -->

<!DOCTYPE html>
<html lang="en">
<head>
  
  <title>Swirlly policy</title>
  <style type="text/css">
    .already{
    background: transparent;
    border: none;
    color: #2980b9;}
   a:link {
  text-decoration: none;

}
.vl_line{
    border-right: 1px solid grey;
}
  </style>

</head>

<body>



<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Start your development with a Design System for Bootstrap 4.">
  <meta name="author" content="Creative Tim">
  <!-- Favicon -->
  <link href="./assets/img/brand/Swirlly.png" rel="icon" type="image/png">
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  <link href="assets/vendor/nucleo/css/nucleo.css" rel="stylesheet">
  <link href="assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <!-- Argon CSS -->
  <link type="text/css" href="assets/css/argon.css?v=1.1.0" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Mansalva&display=swap" rel="stylesheet">
</head>
<header class="header-global">
    <nav id="navbar-main" class="navbar navbar-main navbar-expand-lg navbar-transparent navbar-light headroom">
      <div class="container">
        <a class="navbar-brand mr-lg-5" href="index.php">
          <!-- <img alt="image" src="./assets/img/brand/Swirlly.png"> -->
          <h1 style="color: white ;font-family: 'Mansalva', cursive; ">Swirlly</h1>

        </a>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar_global" aria-controls="navbar_global" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="navbar-collapse collapse" id="navbar_global">
          <div class="navbar-collapse-header">
            <div class="row">
              <div class="col-6 collapse-brand">
                <a href="./index.php">
                  <img alt="image" src="./assets/img/brand/blue.png">
                </a>
              </div>
              <div class="col-6 collapse-close">
                <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbar_global" aria-controls="navbar_global" aria-expanded="false" aria-label="Toggle navigation">
                  <span></span>
                  <span></span>
                </button>
              </div>
            </div>
          </div>
          <ul class="navbar-nav navbar-nav-hover align-items-lg-center">
            <li class="nav-item dropdown">
              <a href="index.php" class="nav-link" data-toggle="dropdown" role="button">
                <i class="ni ni-ui-04 d-lg-none"></i>
               
              </a>
              
            </li>
            
          </ul>

        </div>
      </div>
    </nav>
  </header>
  <main>
    <section class="section section-shaped section-lg">
      <div class="shape shape-style-1 bg-gradient-default">
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
      </div>
      <div class="container pt-lg-md">
        <div class="row justify-content-center">
          <div class="col-lg-12">
            <div class="card bg-secondary shadow border-0">
              <!-- <div class="card-header bg-white pb-5">
                <div class="text-muted text-center mb-3"><small>Sign up with</small></div>
                <div class="text-center">
                  <a href="#" class="btn btn-neutral btn-icon mr-4">
                    <span class="btn-inner--icon">
                      <img src="../assets/img/icons/common/github.svg" alt="image">
                    </span>
                    <span class="btn-inner--text">Github</span>
                  </a>
                  <a href="#" class="btn btn-neutral btn-icon">
                    <span class="btn-inner--icon">
                      <img src="../assets/img/icons/common/google.svg" alt="image">
                    </span>
                    <span class="btn-inner--text">Google</span>
                  </a>
                </div>
              </div>
               --><div class="card-body px-lg-5 py-lg-5">
                <div class="text-center text-muted mb-4">
                  <h2>SWIRLLY POLICY</h2><hr>
                  <center><h4>Terms & Conditions</h4></center>
                </div>
                <p><center><h6>REGISTRATION POLICY</h6></center></p>
                <!-- <center><h6>Terms & Condition</h6></div></center> -->
              		<div class="row"> 	
              			<div class="col-lg-6 vl_line">
<p>• Registration is valid for time period 1 year from the registration date. The vendor has to renew the registration every year in order to continue selling on SWIRLLY.</p>
<p>• The vendor has to pay the accordance percentage (%) which they have selected and agreed with the SWIRLLY offers.</p>
              		<p><b>The three offers’ are:</b></p>
<b><p>i. Register for Rs.499/- and 10% Profit on each product sale.</b>
<b><p>ii.  Register for Rs.399/- and 13% Profit on each product sale.</b>

<b><p>iii.(If you are student) Register for Rs.200/- and 10% profit on each product sale.</b>
<p>• The delivery charges will be included ( added )to their product selling price. The vendors must agree that SWIRLLY may increase the price depending upon the delivery radius (in kms).</p>
<p>• While selling the product SWIRLLY will pack the product under SWIRLLY Co. Logo and
packaging.</p>
<p>• The vendor is responsible for the Fraud and Defective product selling.</p>

</div>
<br><br>

  <div class="col-lg-6">
  	<p>• The vendor should submit the scanned soft copy of required documents for successful  registration in swirlly.</p>

          <b><p>   The documents required are:</b>
       <b><p>  i.   Adhar card(for identity)</b>
       <b><p> ii.  Pan card</b>
       <b><p>iii. Bank passbook Xerox (for money transaction)</b>
       <b><p> vi. Food license (only for cuisine sellers)</b>
    <b><p>     v.  Gst number (if available)</p>
<p>• The vendor is agreeing with the swirlly  offers for customer i.e. exchange and refund offer.</p>
<p>• Vendors should have gst no. if they want to work individually. If they do not have gst no. then they are going to work under swirlly gst no. i.e they are agreeing to work under swirlly management, they will be no longer able to work individually.</p>
<p>By submitting the registration form you are agreeing and satisfied with all the above  policies of swirlly.</p><br><br><br><br><br><br>

 
                     </div></div>

<a href="register.php"><button type="button" class="btn btn-1 btn-outline-primary" align="right">Back</button></a>
                            </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>
<?php include 'footer.php' ?>
  <!-- Core -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/popper/popper.min.js"></script>
  <script src="assets/vendor/bootstrap/bootstrap.min.js"></script>
  <script src="assets/vendor/headroom/headroom.min.js"></script>
  <!-- Argon JS -->
  <script src="assets/js/argon.js?v=1.1.0"></script>

</body>

</html>
