<?php 
	session_start();
	include 'dbconnect.php';
	$pid = $_GET['pid'];
	$target_dir = "products/";
	if(!isset($_SESSION['vid'])){

    echo "<script>
        window.location.href = 'index.php';
    </script>";

    } 

  if(isset($_SESSION['vid'])){

  	$sql = "SELECT * FROM `product_tbl` WHERE pid = $pid AND vid = $_SESSION[vid]";
  	$sql = mysqli_query($con,$sql);
	$counter = 1;
	
		
              	
     

?>


<!--

=========================================================
* Argon Design System - v1.1.0
=========================================================

* Product Page: https://www.creative-tim.com/product/argon-design-system
* Copyright 2019 Creative Tim (https://www.creative-tim.com)
* Licensed under MIT (https://github.com/creativetimofficial/argon-dashboard/blob/master/LICENSE.md)

* Coded by Creative Tim

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software. -->
<!DOCTYPE html>
<html lang="en">
<head>
  <?php include 'navbar.php'; ?>
  <title>View Products</title>
  
</head>

<body>
  <main class="profile-page">
    <section class="section-profile-cover section-shaped my-0">
      <!-- Circles background -->
      <div class="shape shape-style-1 shape-primary alpha-4">
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
      </div>
      <!-- SVG separator -->
      <div class="separator separator-bottom separator-skew">
        <svg x="0" y="0" viewBox="0 0 2560 100" preserveAspectRatio="none" version="1.1" xmlns="http://www.w3.org/2000/svg">
          <polygon class="fill-white" points="2560 0 2560 100 0 100"></polygon>
        </svg>
      </div>
    </section>
    <section class="section">
      <div class="container">
        <div class="card card-profile shadow mt--300">
          <div class="px-4">
            <div class="row justify-content-center">
            <div class="text-center mt-5">
            	<?php if(mysqli_num_rows($sql) > 0){ 
            			while($row = mysqli_fetch_assoc($sql))
        					{ 
            		?>
              <form  method="post" enctype="multipart/form-data" action="uploadproducts.php">
                <div class="form-group">
                    <div class="input-group input-group-alternative mb-3">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="ni ni-cart"></i></span>
                      </div>
                      <input required class="form-control"  value="<?php echo $row['p_name'] ?>" name="product_name" type="text">
                    </div>
                  </div>
                  <div class="input-group input-group-alternative mb-3">
                      <?php
                      		if($row['p_image1'] == $target_dir.''){

                      		}
                      		else{
                      			echo '<img src="$row[p_image1]" >';
                      		}
                       ?>
                  </div>
                  <div class="input-group input-group-alternative mb-3">
                      <?php
                      		if($row['p_image2'] == $target_dir.''){

                      		}
                      		else{
                      			echo '<img src="$row[p_image1]" >';
                      		}
                       ?>
                  </div>
                  <div class="input-group input-group-alternative mb-3">
                      <?php
                      		if($row['p_image3'] == $target_dir.''){

                      		}
                      		else{
                      			echo '<img src="$row[p_image1]" >';
                      		}
                       ?>
                  </div>
                  <div class="input-group input-group-alternative mb-3">
                      <?php
                      		if($row['p_image4'] == $target_dir.''){

                      		}
                      		else{
                      			echo '<img src="$row[p_image1]" >';
                      		}
                       ?>
                  </div>
                  <div class="input-group input-group-alternative mb-3">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fa fa-inr"></i></span>
                      </div>
                      <input required class="form-control"  value="<?php echo $row['p_price'] ?>" name="product_price" type="number">
                  </div>
                  <div class="input-group input-group-alternative mb-3">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fa fa-book"></i></span>
                      </div>
                      <textarea  required name="description" class="form-control" > <?php echo $row['p_description'] ?> </textarea>
                  </div>
                 
                
              </form>
               <div class="text-center">
                    <button  name="update"    class="btn btn-primary mt-4">Add</button>
                     <a href="viewproducts.php"><button class="btn btn-danger mt-4">Back</button></a>

                  </div>
                    <br><br>
            </div>
          </div>
        </div>
      </div>
      <?php    }
    } ?>
    </section>
  </main>
  <?php include 'footer.php'; ?>
  <!-- Core -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/popper/popper.min.js"></script>
  <script src="assets/vendor/bootstrap/bootstrap.min.js"></script>
  <script src="assets/vendor/headroom/headroom.min.js"></script>
  <!-- Argon JS -->
  <script src="assets/js/argon.js?v=1.1.0"></script>
</body>

</html>
<?php } ?>

?>