

<?php 
	session_start();
	include 'dbconnect.php';
  	if(isset($_POST['delete'])){
    	
    	$sql = "DELETE FROM `product_tbl` WHERE pid = $_POST[pid] AND vid = $_SESSION[vid]";
    	if(mysqli_query($con, $sql)){
    		echo "Successfully Deleted";
    	}
  	}


?>