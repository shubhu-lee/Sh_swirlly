<?php 
  include 'dbconnect.php';
  
?>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Start your development with a Design System for Bootstrap 4.">
  <meta name="author" content="Creative Tim">
  <!-- Favicon -->
  <link href="./assets/img/brand/Swirlly.png" rel="icon" type="image/png">
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  <link href="assets/vendor/nucleo/css/nucleo.css" rel="stylesheet">
  <link href="assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <!-- Argon CSS -->
  <link type="text/css" href="assets/css/argon.css?v=1.1.0" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Mansalva&display=swap" rel="stylesheet">
</head>
<header class="header-global">
    <nav id="navbar-main" class="navbar navbar-main navbar-expand-lg navbar-transparent navbar-light headroom">
      <div class="container">
        <a class="navbar-brand mr-lg-5" href="index.php">
          <!-- <img alt="image" src="./assets/img/brand/Swirlly.png"> -->
          <h1 style="color: white ;font-family: 'Mansalva', cursive; ">Swirlly</h1>
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar_global" aria-controls="navbar_global" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="navbar-collapse collapse" id="navbar_global">
          <div class="navbar-collapse-header">
            <div class="row">
              <div class="col-6 collapse-brand" >
                
                <a href="./index.php">
                  
                  <h4 style="color: #5e72e4 ;font-family: 'Mansalva', cursive; ">SWIRLLY</h4>
                </a>

              </div>
              <div class="col-6 collapse-close">
                <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbar_global" aria-controls="navbar_global" aria-expanded="false" aria-label="Toggle navigation">
                  <span></span>
                  <span></span>
                </button>
              </div>
            </div>
          </div>
          <ul class="navbar-nav navbar-nav-hover align-items-lg-center">
            <li class="nav-item dropdown">
              <a href="index.php" class="nav-link" role="button">
                <i class="ni ni-ui-04 d-lg-none"></i>
                <span class="nav-link-inner--text">Home</span>
              </a>
              <!-- <div class="dropdown-menu dropdown-menu-xl">
                <div class="dropdown-menu-inner">
                  <a href="https://demos.creative-tim.com/argon-design-system/docs/getting-started/overview.php" class="media d-flex align-items-center">
                    <div class="icon icon-shape bg-gradient-primary rounded-circle text-white">
                      <i class="ni ni-spaceship"></i>
                    </div>
                    <div class="media-body ml-3">
                      <h6 class="heading text-primary mb-md-1">Getting started</h6>
                      <p class="description d-none d-md-inline-block mb-0">Learn how to use Argon compiling Scss, change brand colors and more.</p>
                    </div>
                  </a>
                  <a href="https://demos.creative-tim.com/argon-design-system/docs/foundation/colors.php" class="media d-flex align-items-center">
                    <div class="icon icon-shape bg-gradient-success rounded-circle text-white">
                      <i class="ni ni-palette"></i>
                    </div>
                    <div class="media-body ml-3">
                      <h6 class="heading text-primary mb-md-1">Foundation</h6>
                      <p class="description d-none d-md-inline-block mb-0">Learn more about colors, typography, icons and the grid system we used for Argon.</p>
                    </div>
                  </a>
                  <a href="https://demos.creative-tim.com/argon-design-system/docs/components/alerts.php" class="media d-flex align-items-center">
                    <div class="icon icon-shape bg-gradient-warning rounded-circle text-white">
                      <i class="ni ni-ui-04"></i>
                    </div>
                    <div class="media-body ml-3">
                      <h5 class="heading text-warning mb-md-1">Components</h5>
                      <p class="description d-none d-md-inline-block mb-0">Browse our 50 beautiful handcrafted components offered in the Free version.</p>
                    </div>
                  </a>
                </div>
              </div> -->
            </li>
            <li class="nav-item dropdown">
              <a href="aboutus.php" class="nav-link"  role="button">
                <i class="ni ni-collection d-lg-none"></i>
                <span class="nav-link-inner--text">About Us</span>
              </a>
              <!-- <div class="dropdown-menu">
                <a href="./landing.php" class="dropdown-item">Landing</a>
                <a href="./profile.php" class="dropdown-item">Profile</a>
                <a href="./login.php" class="dropdown-item">Login</a>
                <a href="./register.php" class="dropdown-item">Register</a>
              </div> -->
            </li>
          </ul>
          <ul class="navbar-nav align-items-lg-center ml-lg-auto">
            <li class="nav-item">
              <a class="nav-link nav-link-icon" href="https://www.facebook.com/creativetim" target="_blank" data-toggle="tooltip" title="Like us on Facebook">
                <i class="fa fa-facebook-square"></i>
                <span class="nav-link-inner--text d-lg-none">Facebook</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link nav-link-icon" href="https://www.instagram.com/swirllypvtltd/" target="_blank" data-toggle="tooltip" title="Follow us on Instagram">
                <i class="fa fa-instagram"></i>
                <span class="nav-link-inner--text d-lg-none">Instagram</span>
              </a>

            <!-- <li class="nav-item">
              <a class="nav-link nav-link-icon" href="https://twitter.com/creativetim" target="_blank" data-toggle="tooltip" title="Follow us on Twitter">
                <i class="fa fa-twitter-square"></i>
                <span class="nav-link-inner--text d-lg-none">Twitter</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link nav-link-icon" href="https://github.com/creativetimofficial/argon-design-system" target="_blank" data-toggle="tooltip" title="Star us on Github">
                <i class="fa fa-github"></i>
                <span class="nav-link-inner--text d-lg-none">Github</span>
              </a>
            </li> -->
            <?php if(!isset($_SESSION["vid"])){ ?>

            <li class="nav-item d-none d-lg-block ml-lg-4">
              <a href="login.php" target="" class="btn btn-neutral btn-icon">
                <span class="btn-inner--icon">
                  <i class="fa fa-user mr-2"></i>
                </span>
                <span class="nav-link-inner--text">Login</span>
              </a>
            </li>
            <li class="nav-item d-none d-lg-block ml-lg-4">
              <a href="register.php" target="" class="btn btn-neutral btn-icon">
                <span class="btn-inner--icon">
                  <i class="fa fa-user mr-2"></i>
                </span>
                <span class="nav-link-inner--text">Register as a Seller</span>
              </a>
            </li>
          <?php } else{ ?>
            </li>
            <li class="nav-item">
              <a class="nav-link nav-link-icon" href="https://www.facebook.com/creativetim" target="_blank" data-toggle="tooltip" title="Notifications">
                <i class="fa fa-bell-o"></i>
                <span class="nav-link-inner--text d-lg-none">Notifications</span>
                <span class="badge" style="background: steelblue;"></span>
              </a>

            </li>
            <li class="nav-item  d-lg-block ml-lg-4">
              <a href="profile.php" target="" class="btn btn-neutral btn-icon">
                <span class="btn-inner--icon">
                  <i class="fa fa-user mr-2"></i>
                </span>
                <span class="nav-link-inner--text">Profile</span>
              </a>
            </li>
            
            <li class="nav-item  d-lg-block ml-lg-4">
              <a href="logout.php" target="" class="btn btn-neutral btn-icon">
                <span class="btn-inner--icon">
                  <i class="fa fa-user mr-2"></i>
                </span>
                <span class="nav-link-inner--text">Logout</span>
              </a>
            </li>
            
          <?php  } ?>
          </ul>
        </div>
      </div>
    </nav>
  </header>